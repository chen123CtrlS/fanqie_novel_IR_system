from collections import Counter
import numpy as np
import os
import jieba
import pickle

from collections import defaultdict
# 构造倒排索引
# postings list中每一项为一个Posting类对象
class Posting(object):
    def __init__(self, docid, tf=0):
        self.docid = docid
        self.tf = tf
    def __repr__(self):
        return "<docid: %d, tf: %d>" % (self.docid, self.tf)

def get_postings_list(inverted_index, query_term):
    try:
        return inverted_index[query_term][1:]
    except KeyError:
        return []

def cosine_scores_TAAT(inverted_index, doc_length, frequency_dict, query, k=3):
    scores = defaultdict(lambda: 0.0) # 保存分数
    query_terms = Counter(term for term in jieba.lcut_for_search(query)) # 对查询进行分词
    #print(query_terms)_Counter({'...': 1})
    query_len=[]
    for q in query_terms:
        if q in frequency_dict:
            idf=np.array(frequency_dict[q])
        else:
            continue
        w_tq = np.log(1 + query_terms[q])*idf
        #w_tq = (1+np.log( query_terms[q]))*idf
        query_len.append(w_tq)
        postings_list = get_postings_list(inverted_index, q)
        for posting in postings_list:
            w_td = np.log(1 + posting.tf)
            scores[posting.docid] += w_td * w_tq
    zc=np.array(query_len)
    lenth_=np.sqrt(np.sum(zc**2))#考虑idf后对向量的归一化
    results = [(score /(( doc_length[docid]+1)*lenth_), docid) for docid, score in scores.items()]
    sorted(results)[::-1]
    return results[0:k]

def retrieval_by_cosine_sim(inverted_index,abstract_length, data, frequency_dict, query, k=20):
    top_scores = cosine_scores_TAAT(inverted_index, abstract_length, frequency_dict, query, k=k)
    results = [ {'url':data[docid]['url'],'title':data[docid]['title'],'author':data[docid]['author'],'abstract':data[docid]['abstract']} for score,docid in top_scores]
    return results

def evaluate(abstract_inverted_index,abstract_length, abstract_data,abstract_frequency_dict,query:str) -> list:
    url_list=retrieval_by_cosine_sim(abstract_inverted_index,abstract_length, abstract_data,abstract_frequency_dict, query=query, k=15)
    return url_list

def retrieval_by_cosine_sim1(inverted_index,abstract_length, data, frequency_dict, query, k=20):
    top_scores = cosine_scores_TAAT(inverted_index, abstract_length, frequency_dict, query, k=k)
    results = [ {'novel':data[docid]['novel'],'home':data[docid]['home'],'url':data[docid]['url'],'title':data[docid]['title']} for score,docid in top_scores]
    return results

def evaluate1(inverted_index,chapter_length, all_chapters, frequency_dict,query:str) -> list:
    url_list=retrieval_by_cosine_sim1(inverted_index,chapter_length, all_chapters, frequency_dict, query=query, k=15)
    return url_list

if __name__ == '__main__':
    with open(r"abstract.pickle", 'rb') as f:
        data = pickle.load(f),
    abstract_frequency_dict = data[0]['frequency_dict']
    abstract_length = data[0]['abstract_length']
    abstract_inverted_index = data[0]['inverted_index']
    abstract_data = data[0]['data']

    with open(r"chapter.pickle", 'rb') as f:
        data = pickle.load(f),
    frequency_dict = data[0]['frequency_dict']
    chapter_length = data[0]['chapter_length']
    inverted_index = data[0]['inverted_index']
    all_chapters = data[0]['all_chapters']

    print(evaluate(abstract_inverted_index,abstract_length, abstract_data,abstract_frequency_dict,'废物'))

    print(evaluate1(inverted_index, chapter_length, all_chapters, frequency_dict, '长生'))